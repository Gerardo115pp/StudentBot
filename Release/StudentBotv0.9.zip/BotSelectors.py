
class MeetSelectors:
    SET_CLASS_CODE_BTN = "#yDmH0d > c-wiz > div > div > div > div.CWHuqf > div.FaHE5b > div.hX3ife > div > c-wiz > div:nth-child(1) > div > div > div.ox9SMb.jginQb"
    CODE_INPUT = "input.poFWNe.zHQkBf"
    CLASS_CONTINUE_BTN = "#yDmH0d > div.llhEMd.iWO5td > div > div.g3VIld.Xpwrdc.JLm1tf-Jyewjb.Up8vH.hFEqNb.J9Nfi.iWO5td > span > div > div.QnTWsf > div.Jsqtqc > div > span"
    CLOSE_CAMMIC_ALERT = "#yDmH0d > div.llhEMd.iWO5td > div > div.g3VIld.vdySc.Up8vH.J9Nfi.iWO5td > div.XfpsVe.J9fJmf > div > span > span"
    JOIN_BTN = "#yDmH0d > c-wiz > div > div > div:nth-child(6) > div.crqnQb > div > div > div.vgJExf > div > div.KieQAe > div.d7iDfe.NONs6c > div > div.Sla0Yd > div > div.XCoPyb > div.uArJ5e.UQuaGc.Y5sE8d.uyXBBb.xKiqt > span"
    CLOSE_INVITE_DIALOG = "#yDmH0d > div.llhEMd.iWO5td > div > div.g3VIld.QuP9wb.Up8vH.hFEqNb.J9Nfi.iWO5td > div.R6Lfte.tOrNgd.qRUolc > div.VY7JQd > div"
    CLOSE_CALL = "#ow3 > div.T4LgNb > div > div:nth-child(6) > div.crqnQb > div.rG0ybd.LCXT6 > div.q2u11 > div.s1GInc.zCbbgf > div"
    PEOPLE_COUNT = "#ow3 > div.T4LgNb > div > div:nth-child(6) > div.crqnQb > div.pHsCke > div.Jrb8ue > div > div.NzPR9b > div.uArJ5e.UQuaGc.kCyAyd.QU4Gid.foXzLb.IeuGXd > span > span > div > div > span.wnPUne.N0PJ8e"
    COMMENTS_CLASS = ".GDhqjd"
    CHAT_BTN = "div.NzPR9b > div:nth-child(3) > span > span"